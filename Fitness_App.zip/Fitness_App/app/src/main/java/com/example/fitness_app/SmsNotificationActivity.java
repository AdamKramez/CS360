package com.example.fitness_app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


public class SmsNotificationActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    private androidx.appcompat.widget.SwitchCompat toggleGoalReached, toggleDailyReminder, toggleNearGoal;
    private TextView permissionStatusText;
    private boolean smsPermissionGranted = false;

    private RadioGroup unitToggleGroup;
    private RadioButton unitKg, unitLb;

    public static boolean isKgSelected = false;
    public static boolean isGoalNotificationEnabled = false;

    private CompoundButton pendingToggle = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sms_notification);

        // handle modern system insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.smsNotificationLayout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // link ui elements
        toggleGoalReached = findViewById(R.id.toggleGoalReached);
        toggleDailyReminder = findViewById(R.id.toggleDailyReminder);
        toggleNearGoal = findViewById(R.id.toggleNearGoal);
        permissionStatusText = findViewById(R.id.permissionStatusText);
        unitToggleGroup = findViewById(R.id.unitToggleGroup);
        unitKg = findViewById(R.id.unitKg);
        unitLb = findViewById(R.id.unitLb);

        // check sms permission on startup
        checkSmsPermission();

        // handle toggle for goal reached notification
        toggleGoalReached.setOnCheckedChangeListener((buttonView, isChecked) -> {
            isGoalNotificationEnabled = isChecked;
            if (isChecked) {
                handleSmsToggle(buttonView);
            }
        });

        // handle toggle for daily reminder notification
        toggleDailyReminder.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                handleSmsToggle(buttonView);
            }
        });

        // handle toggle for near goal notification
        toggleNearGoal.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                handleSmsToggle(buttonView);
            }
        });

        // handle unit toggle between kg and lb
        unitToggleGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.unitKg) {
                isKgSelected = true;
                Toast.makeText(SmsNotificationActivity.this, "units set to kg", Toast.LENGTH_SHORT).show();
            } else if (checkedId == R.id.unitLb) {
                isKgSelected = false;
                Toast.makeText(SmsNotificationActivity.this, "units set to lb", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void handleSmsToggle(CompoundButton toggleButton) {
        if (smsPermissionGranted) {
            // if permission granted, show fake sms preview
            if (toggleButton == toggleGoalReached) {
                Toast.makeText(this, "sms: congratulations! goal reached!", Toast.LENGTH_SHORT).show();
            } else if (toggleButton == toggleDailyReminder) {
                Toast.makeText(this, "sms: reminder to track your weight today!", Toast.LENGTH_SHORT).show();
            } else if (toggleButton == toggleNearGoal) {
                Toast.makeText(this, "sms: you're close to your goal weight!", Toast.LENGTH_SHORT).show();
            }
        } else {
            // if no permission, prompt for permission
            pendingToggle = toggleButton;
            showPermissionDialog();
        }
    }

    private void showPermissionDialog() {
        // show dialog asking user for sms permission
        new AlertDialog.Builder(this)
                .setTitle("SMS permission needed")
                .setMessage("This feature requires permission to send sms. Would you like to allow it?")
                .setPositiveButton("Allow", (dialog, which) -> requestSmsPermission())
                .setNegativeButton("Deny", (dialog, which) -> {
                    if (pendingToggle != null) {
                        pendingToggle.setChecked(false);
                        pendingToggle = null;
                    }
                    Toast.makeText(this, "Permission denied. Cannot send sms.", Toast.LENGTH_SHORT).show();
                })
                .setCancelable(false)
                .show();
    }

    private void requestSmsPermission() {
        // request sms permission from user
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    private void checkSmsPermission() {
        // check if sms permission already granted
        smsPermissionGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
        permissionStatusText.setText(smsPermissionGranted ? "SMS permission: granted" : "SMS permission: denied");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            smsPermissionGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED;

            if (smsPermissionGranted) {
                permissionStatusText.setText(getString(R.string.sms_permission_granted));
                Toast.makeText(this, "Permission granted! SMS features active.", Toast.LENGTH_SHORT).show();
                if (pendingToggle != null) {
                    pendingToggle.setChecked(true);
                    pendingToggle = null;
                }
            } else {
                permissionStatusText.setText(getString(R.string.sms_permission_denied));

                // if permission still denied, suggest user to open app settings
                new AlertDialog.Builder(this)
                        .setTitle("Permission denied")
                        .setMessage("You must manually enable sms permission from app settings.")
                        .setPositiveButton("Open settings", (dialog, which) -> openAppSettings())
                        .setNegativeButton("Cancel", (dialog, which) -> {
                            if (pendingToggle != null) {
                                pendingToggle.setChecked(false);
                                pendingToggle = null;
                            }
                            Toast.makeText(this, "Permission denied. Cannot send sms.", Toast.LENGTH_SHORT).show();
                        })
                        .setCancelable(false)
                        .show();
            }
        }
    }

    private void openAppSettings() {
        // open app settings so user can manually grant permissions
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivity(intent);
    }
}
