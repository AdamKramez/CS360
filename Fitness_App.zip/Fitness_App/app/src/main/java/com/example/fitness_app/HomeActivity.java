package com.example.fitness_app;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class HomeActivity extends AppCompatActivity {

    private LineChart lineChart;
    private Button enterWeightButton;
    private Button setGoalButton;
    private TextView goalWeightDisplay;
    private TextView latestWeightDisplay;
    private DatabaseHelper databaseHelper;
    private double goalWeight = 0.0;
    private String currentUser = "";

    private HashMap<Integer, Integer> indexToWeightIdMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // link ui elements
        lineChart = findViewById(R.id.weightLineChart);
        enterWeightButton = findViewById(R.id.enterWeightButton);
        setGoalButton = findViewById(R.id.setGoalButton);
        goalWeightDisplay = findViewById(R.id.goalWeightDisplay);
        latestWeightDisplay = findViewById(R.id.latestWeightDisplay);

        // initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // get current user from session
        currentUser = SessionManager.getUsername(this);

        // if no user found, redirect to login
        if (currentUser == null || currentUser.isEmpty()) {
            Toast.makeText(this, "no user session found. please log in again.", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        // fetch user's goal weight
        goalWeight = databaseHelper.getGoalWeight(currentUser);

        updateGoalWeightDisplay();
        loadWeightData();

        // set up button listeners
        enterWeightButton.setOnClickListener(view -> showAddWeightDialog());

        setGoalButton.setOnClickListener(view -> {
            Intent intent = new Intent(HomeActivity.this, SmsNotificationActivity.class);
            startActivity(intent);
        });

        goalWeightDisplay.setOnClickListener(view -> showGoalWeightDialog());

        setupChartListener();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadWeightData(); // reload data when returning to screen
    }

    private void showAddWeightDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter Today's Weight");

        final EditText input = new EditText(this);
        input.setHint("Weight (" + (SmsNotificationActivity.isKgSelected ? "kg" : "lb") + ")");
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String weightStr = input.getText().toString().trim();
            if (!weightStr.isEmpty()) {
                try {
                    double weight = Double.parseDouble(weightStr);

                    // if user is using lb, convert it to kg before saving
                    if (!SmsNotificationActivity.isKgSelected) {
                        weight = weight / 2.20462;
                    }

                    String todayDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

                    boolean success = databaseHelper.addWeight(todayDate, weight, currentUser);
                    if (success) {
                        Toast.makeText(HomeActivity.this, "Weight added!", Toast.LENGTH_SHORT).show();
                        loadWeightData();
                    } else {
                        Toast.makeText(HomeActivity.this, "Error saving weight.", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(HomeActivity.this, "Invalid number format.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(HomeActivity.this, "Please enter a weight.", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }


    private void showGoalWeightDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Set Your Goal Weight");

        final EditText input = new EditText(this);
        input.setHint("Goal Weight (" + (SmsNotificationActivity.isKgSelected ? "kg" : "lb") + ")");
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String weightStr = input.getText().toString().trim();
            if (!weightStr.isEmpty()) {
                try {
                    double inputGoalWeight = Double.parseDouble(weightStr);

                    // if user is using lb, convert to kg before saving
                    if (!SmsNotificationActivity.isKgSelected) {
                        inputGoalWeight = inputGoalWeight / 2.20462;
                    }

                    goalWeight = inputGoalWeight;
                    databaseHelper.setGoalWeight(goalWeight, currentUser);

                    updateGoalWeightDisplay();
                    loadWeightData();
                    Toast.makeText(HomeActivity.this, "Goal weight set!", Toast.LENGTH_SHORT).show();
                } catch (NumberFormatException e) {
                    Toast.makeText(HomeActivity.this, "Invalid number format.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }


    private void updateGoalWeightDisplay() {
        // update goal weight text based on unit selection
        double displayedGoalWeight = goalWeight;
        String unit = "kg";

        if (!SmsNotificationActivity.isKgSelected) {
            displayedGoalWeight = goalWeight * 2.20462; // convert to lb
            unit = "lb";
        }

        goalWeightDisplay.setText(String.format(Locale.getDefault(), "Goal Weight: %.1f %s", displayedGoalWeight, unit));
    }

    private void loadWeightData() {
        // reload goal weight in case units changed
        updateGoalWeightDisplay();

        ArrayList<Entry> weightEntries = new ArrayList<>();
        indexToWeightIdMap.clear();
        Cursor cursor = databaseHelper.getAllWeights(currentUser);

        int idx = 0;
        float latestWeight = -1;
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                double weight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"));

                if (!SmsNotificationActivity.isKgSelected) {
                    weight = weight * 2.20462; // kg -> lb
                }

                weightEntries.add(new Entry(idx, (float) weight));
                indexToWeightIdMap.put(idx, id);

                latestWeight = (float) weight;
                idx++;
            } while (cursor.moveToNext());
        }
        cursor.close();

        if (latestWeight != -1) {
            latestWeightDisplay.setText("Latest Entry: " + String.format("%.1f", latestWeight) + (SmsNotificationActivity.isKgSelected ? " kg" : " lb"));
        } else {
            latestWeightDisplay.setText("No entries yet.");
        }

        if (weightEntries.isEmpty()) {
            Toast.makeText(this, "no weight entries yet. add your first weight!", Toast.LENGTH_SHORT).show();
            lineChart.clear();
            return;
        }

        // create dataset for the chart
        LineDataSet dataSet = new LineDataSet(weightEntries, "Weight Over Time");
        dataSet.setColor(android.graphics.Color.BLUE);
        dataSet.setValueTextColor(android.graphics.Color.BLACK);
        dataSet.setCircleColor(android.graphics.Color.RED);
        dataSet.setCircleRadius(5f);
        dataSet.setLineWidth(2f);
        dataSet.setValueTextSize(12f);

        LineData lineData = new LineData(dataSet);

        // draw goal weight line
        if (goalWeight > 0) {
            List<Entry> goalLine = new ArrayList<>();
            float adjustedGoal = (float) (SmsNotificationActivity.isKgSelected ? goalWeight : goalWeight * 2.20462);
            goalLine.add(new Entry(0, adjustedGoal));
            goalLine.add(new Entry(weightEntries.size() - 1, adjustedGoal));

            LineDataSet goalDataSet = new LineDataSet(goalLine, "Goal Weight");
            goalDataSet.setColor(android.graphics.Color.GREEN);
            goalDataSet.setLineWidth(2f);
            goalDataSet.setDrawCircles(false);
            goalDataSet.setValueTextSize(0f);

            lineData.addDataSet(goalDataSet);
        }

        lineChart.setData(lineData);

        // customize x axis to show dates
        XAxis xAxis = lineChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                int position = Math.round(value);
                Cursor dateCursor = databaseHelper.getAllWeights(currentUser);
                if (dateCursor.moveToPosition(position)) {
                    String date = dateCursor.getString(dateCursor.getColumnIndexOrThrow("date"));
                    dateCursor.close();
                    return date.substring(5); // show month and day
                } else {
                    dateCursor.close();
                    return "";
                }
            }
        });

        // customize y axis
        YAxis leftAxis = lineChart.getAxisLeft();
        YAxis rightAxis = lineChart.getAxisRight();
        rightAxis.setEnabled(false);

        leftAxis.setAxisMinimum(findMinWeight(weightEntries) - 5);
        leftAxis.setAxisMaximum(findMaxWeight(weightEntries) + 5);

        lineChart.getDescription().setText("Progress Over Time");
        lineChart.animateX(1000);
        lineChart.invalidate();
    }

    private void setupChartListener() {
        // set up listener to delete weight entries by clicking the graph
        lineChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry e, Highlight h) {
                int index = (int) e.getX();
                if (indexToWeightIdMap.containsKey(index)) {
                    int weightId = indexToWeightIdMap.get(index);
                    confirmDeleteWeight(weightId);
                }
            }

            @Override
            public void onNothingSelected() {}
        });
    }

    private void confirmDeleteWeight(int weightId) {
        // confirmation dialog to delete a weight
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Weight Entry");
        builder.setMessage("Are you sure you want to delete this weight entry?");
        builder.setPositiveButton("Delete", (dialog, which) -> {
            databaseHelper.deleteWeightById(weightId);
            Toast.makeText(this, "weight entry deleted!", Toast.LENGTH_SHORT).show();
            loadWeightData();
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private float findMinWeight(ArrayList<Entry> entries) {
        // find minimum weight to set y axis range
        float min = Float.MAX_VALUE;
        for (Entry e : entries) {
            if (e.getY() < min) min = e.getY();
        }
        return min;
    }

    private float findMaxWeight(ArrayList<Entry> entries) {
        // find maximum weight to set y axis range
        float max = Float.MIN_VALUE;
        for (Entry e : entries) {
            if (e.getY() > max) max = e.getY();
        }
        return max;
    }
}
