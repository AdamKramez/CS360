package com.example.fitness_app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText usernameInput, passwordInput;
    Button loginButton, createAccountButton;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // handle modern system insets for a better ui experience
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // link ui elements to java variables
        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        // initialize the database helper
        databaseHelper = new DatabaseHelper(this);

        // handle login button click
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = usernameInput.getText().toString().trim();
                String password = passwordInput.getText().toString().trim();

                // check if fields are empty
                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "please enter both username and password", Toast.LENGTH_SHORT).show();
                } else {
                    // check if user credentials are correct
                    boolean success = databaseHelper.checkUser(username, password);
                    if (success) {
                        // save user session and move to home screen
                        SessionManager.saveUsername(MainActivity.this, username);
                        Toast.makeText(MainActivity.this, "login successful", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(MainActivity.this, "invalid credentials", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // handle create account button click
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = usernameInput.getText().toString().trim();
                String password = passwordInput.getText().toString().trim();

                // check if fields are empty
                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "please enter both username and password", Toast.LENGTH_SHORT).show();
                } else {
                    // try to create a new user in the database
                    boolean success = databaseHelper.addUser(username, password);
                    if (success) {
                        Toast.makeText(MainActivity.this, "account created successfully. you can now log in.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "error creating account", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
