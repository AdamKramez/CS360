package com.example.fitness_app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "fitness_app.db";
    private static final int DATABASE_VERSION = 2;

    private static final String TABLE_WEIGHTS = "weights";
    private static final String COLUMN_WEIGHT_ID = "id";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_WEIGHT = "weight";
    private static final String COLUMN_WEIGHT_USERNAME = "username";

    private static final String TABLE_GOALS = "goals";
    private static final String COLUMN_GOAL_ID = "id";
    private static final String COLUMN_GOAL_WEIGHT = "goalWeight";
    private static final String COLUMN_GOAL_USERNAME = "username";

    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // create users table
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT UNIQUE, " +
                COLUMN_PASSWORD + " TEXT)";
        db.execSQL(createUsersTable);

        // create weights table
        String createWeightsTable = "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                COLUMN_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_DATE + " TEXT, " +
                COLUMN_WEIGHT + " REAL, " +
                COLUMN_WEIGHT_USERNAME + " TEXT)";
        db.execSQL(createWeightsTable);

        // create goals table
        String createGoalsTable = "CREATE TABLE " + TABLE_GOALS + " (" +
                COLUMN_GOAL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_GOAL_WEIGHT + " REAL, " +
                COLUMN_GOAL_USERNAME + " TEXT UNIQUE)";
        db.execSQL(createGoalsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // drop old tables if they exist
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOALS);
        onCreate(db);
    }

    public boolean addUser(String username, String password) {
        // add a new user to the users table
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    public boolean checkUser(String username, String password) {
        // check if a user exists with matching credentials
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " +
                COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?", new String[]{username, password});
        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }

    public boolean addWeight(String date, double weight, String username) {
        // add a new weight entry for a user
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);
        values.put(COLUMN_WEIGHT_USERNAME, username);
        long result = db.insert(TABLE_WEIGHTS, null, values);
        return result != -1;
    }

    public Cursor getAllWeights(String username) {
        // get all weight entries for a specific user
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_WEIGHTS + " WHERE " + COLUMN_WEIGHT_USERNAME + "=? ORDER BY " + COLUMN_DATE + " ASC", new String[]{username});
    }

    public void deleteWeightById(int weightId) {
        // delete a weight entry by its id
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_WEIGHTS, COLUMN_WEIGHT_ID + "=?", new String[]{String.valueOf(weightId)});
    }

    public void setGoalWeight(double goalWeight, String username) {
        // set or update a user's goal weight
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_GOAL_WEIGHT, goalWeight);
        values.put(COLUMN_GOAL_USERNAME, username);

        int rows = db.update(TABLE_GOALS, values, COLUMN_GOAL_USERNAME + "=?", new String[]{username});
        if (rows == 0) {
            db.insert(TABLE_GOALS, null, values);
        }
    }

    public double getGoalWeight(String username) {
        // get the stored goal weight for a specific user
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_GOAL_WEIGHT + " FROM " + TABLE_GOALS + " WHERE " + COLUMN_GOAL_USERNAME + "=?", new String[]{username});

        if (cursor.moveToFirst()) {
            double goal = cursor.getDouble(0);
            cursor.close();
            return goal;
        } else {
            cursor.close();
            return 0.0;
        }
    }
}
